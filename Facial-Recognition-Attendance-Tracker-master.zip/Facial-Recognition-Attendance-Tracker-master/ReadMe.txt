FACIAL RECOGNITION BASED ATTENDANCE RACKER FOR UNIVERSITY

This project uses OpenCV and Face-recognition Modules along with dlib, cmake, os, numpy. 
It detects and encodes the faces and recognises poeple with the help of university database

A CSV sheet is maintained where names along with time and date of detection are added and attendenc ismarked

The Dataset used is of our own class of about 50 students. 
The accuracy of this model can be improved. we've imporved the speed of execution by storing the encodings of our Dataset

